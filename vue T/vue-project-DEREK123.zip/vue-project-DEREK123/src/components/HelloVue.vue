<script setup>
// JavaScript
</script>

<template>
    <!-- HTML -->
    <h1>Hello Vue</h1>
</template>

<style scoped>
/* CSS */
h1 {
    color: yellowgreen;
}
</style>