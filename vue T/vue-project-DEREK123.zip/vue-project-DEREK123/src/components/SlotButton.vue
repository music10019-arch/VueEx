<script setup></script>

<template>
    <!-- <ul>
        <li>
            <slot></slot>
        </li>
        <li>
            <slot></slot>
        </li>
        <li>
            <slot></slot>
        </li>
    </ul> -->

    <slot name="leftIcon"></slot>
    <button>
        <slot></slot>
    </button>
    <slot name="rightIcon"></slot>

</template>

<style scoped></style>