<script setup>

// const props = defineProps(["title","msg"]);
const props = defineProps({
    title: String,
    msg: { type: String, required: true },
    count: { type: Number, default: 10 }
});


const emit = defineEmits(["btnClicked123", "test1"]);

function handleClick() {
    // console.log('here');
    emit("btnClicked123", { name: 123 });
}

</script>

<template>


    <h3>我是子組件</h3>
    <button @click="handleClick()">子元件按鈕</button>

    {{ props.title }}
    {{ props.msg }}
    {{ props.count }}

</template>

<style scoped></style>