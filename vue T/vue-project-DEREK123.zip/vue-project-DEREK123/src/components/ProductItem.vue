<script setup>
import { Product } from '@/common/product';


// const props = defineProps(["name", "price"]);
const props = defineProps({
    product: Product
})
const emit = defineEmits(["click"]);

function addCart() {
    emit("click", props.product);
}

</script>

<template>
    <div class="product-card">
        <h3 class="product-name">{{ props.product.name }}</h3>
        <p class="product-price">$ {{ props.product.price }}</p>
        <button class="add-btn" @click="addCart()">
            加入購物車
        </button>
    </div>
</template>


<style scoped>
.product-card {
    height: 280px;
    width: 220px;
    padding: 16px;
    border-radius: 12px;
    background: #ffffff;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
    text-align: center;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.product-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.12);
}

.product-name {
    height: 150px;
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 8px;
    color: #333;
}

.product-price {
    font-size: 16px;
    color: #e53935;
    margin-bottom: 16px;
}

.add-btn {
    width: 100%;
    padding: 10px 0;
    border: none;
    border-radius: 8px;
    background-color: #42b883;
    color: #fff;
    font-size: 15px;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.add-btn:hover {
    background-color: #369f6e;
}
</style>