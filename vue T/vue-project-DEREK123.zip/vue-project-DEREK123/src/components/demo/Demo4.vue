<script setup>

const printLog = (eventObj) => {
    console.log('print success!');
    console.log(eventObj);
}

const printLog1 = (obj, name) => {
    console.log('print success!');
    console.log(obj);
    console.log(name);
}


// document.querySelector('button').addEventListener('click', printLog);


</script>

<template>

    <!-- <button onclick="printLog"></button> -->
    <button v-on:click="printLog">按鈕Method</button>
    <button v-on:click="printLog1($event, 'Derek')">按鈕Inline</button>
    <button v-on:click="(e) => printLog1(e, 'Sam')">按鈕Inline</button>
</template>

<style scoped></style>