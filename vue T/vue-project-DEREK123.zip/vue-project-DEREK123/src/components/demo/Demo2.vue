<script setup>

const msg = `<h1>本文插值</h1>`;
const msg1 = `<img src="error.jpg" onerror="alert('XSS 攻擊!');document.body.append('攻擊內容!!!');">`

</script>

<template>
    <!-- <img src="error111.jpg" onerror="alert('XSS 攻擊!');document.body.append('攻擊內容!!!');"> -->
    <p v-html="msg1"></p>

</template>

<style scoped></style>