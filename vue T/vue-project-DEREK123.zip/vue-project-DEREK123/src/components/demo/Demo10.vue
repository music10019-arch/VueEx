<script setup>
import { ref, watch } from 'vue';
import memberData from '../../data/member.json';

const member = ref(memberData[0]);

document.querySelector('div')
    .addEventListener('click', (eventObject) => { })

watch(member, (newVal, oldValue) => {
    console.log(newVal, oldValue);
}, { immediate: true, deep: true })

watch(() => member.value.age, (newVal, oldValue) => {
    console.log(newVal, oldValue);
})

function addAge() {
    member.value.age = member.value.age + 1;
}
function changeMember() {
    const index = Math.floor(Math.random() * 10);
    member.value = memberData[index];
}

// =================
import { watchEffect } from 'vue';

const name = ref('Derek');
const age = ref(0);

watchEffect(() => {
    // console.log('name改變了', name.value);
    console.log('age改變了', age.value);
})

</script>

<template>
    <h1>{{ member.name }}</h1>
    <h2>{{ member.age }}</h2>
    <button @click="addAge()">年齡加1</button>
    <button @click="changeMember()">換會員</button>

    <hr />

    <input type="text" v-model="name" />
    <input type="number" v-model="age" />

</template>

<style scoped></style>