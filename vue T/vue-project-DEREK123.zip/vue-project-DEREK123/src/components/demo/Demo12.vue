<script setup>

import { ref } from 'vue';
import foodData from '../../data/food.json';

const foodItems = ref(foodData);

const selectedItem = ref(-1);

const obj = {
    "id": 3,
    "name": "雙層牛肉吉事堡套餐"
};
//              0    1    2
const array = ["a", "b", "c"];

for (const key in foodItems.value[3]) {
    console.log(key);
}

for (const index in array) {
    console.log(index);
}

</script>

<template>

    <select v-model="selectedItem">
        <option disabled :value="-1">請選擇</option>
        <option v-for="(value, index) in foodItems" :key="value.id" :value="value.id">
            {{ `${index + 1}_${value.name}` }}
        </option>
    </select>
    選擇的ID：{{ selectedItem }}

    <p v-for="(value, key) in foodItems[3]">
        {{ value }} {{ key }}
    </p>


</template>

<style scoped></style>