<script setup>

import SlotButton from '../SlotButton.vue';
import PokemonCard from '../PokemonCard.vue';
import PokemonData from '../../data/pokemon.json';

const pokemon = PokemonData[0];

console.log(pokemon);

</script>

<template>

    <SlotButton>
        <template #leftIcon>
            ☆
        </template>
        <template #rightIcon>
            ★
        </template>
        切換
    </SlotButton>

    <hr />
    {{ pokemon.name }}

    <PokemonCard name="TEST">
        <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png" />
        <template #types>4</template>
        <template #number>5</template>
    </PokemonCard>


</template>

<style scoped></style>