<script setup>

// logic => myId

const dynamicId = "myId1";

// const aTag = document.querySelector('a'); // DOM
// aTag.href = "http://google.com.tw";

const url = "http://google.com.tw";

const target1 = null;

const isDisabled = true;

const attrObj = { "key": "value", "style": "color:red;" }
attrObj.id = "myId";
attrObj["class"] = "myClass";
console.log(attrObj);

const attributeName = "id";

</script>

<template>
    <!-- <h1 id="myId">我是標題</h1> -->
    <h1 v-bind:id="dynamicId">我是標題</h1>

    <a v-bind:href="url" :target="target1">Google</a>
    <a v-bind:href="url" target="_blank">Google</a>

    <button :disabled="isDisabled">按鈕</button>
    <button :disabled="!isDisabled">按鈕</button>

    <h2 v-bind="attrObj">標題2</h2>
    <h2 :="attrObj">標題2</h2>

    <h3 v-bind:[attributeName]="dynamicId">標題3</h3>

</template>

<style scoped></style>