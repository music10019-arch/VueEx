<script setup>

import { ref } from 'vue';

const isShow = ref(true);

</script>

<template>

    <button @click="isShow = !isShow">切換</button>
    <Transition>
        <h1 v-show="isShow">Hello</h1>
    </Transition>

</template>

<style scoped>
/* 進入起始 */
.v-enter-from,
/* 離開終點 */
.v-leave-to {
    opacity: 0.2;
    color: red;
}

/* 進入終點 */
.v-enter-to,
/* 離開起始 */
.v-leave-from {
    opacity: 1;
    color: yellow
}

/* 過度 */
.v-enter-active,
.v-leave-active {
    transition: opacity 5s linear, color 3s cubic-bezier(.11, 1.45, .66, -1.2)
}
</style>