<script setup>
import ProjButton from '../ProjButton.vue';


const props = defineProps({ 'modelValue': String });
const emit = defineEmits(['update:modelValue']);

</script>

<template>

    <input :value="props.modelValue" @input="(event) => emit('update:modelValue', event.target.value)">


    <ProjButton type="search"></ProjButton>
    <ProjButton type="add"></ProjButton>
    <ProjButton type="addTEST"></ProjButton>


</template>

<style scoped></style>