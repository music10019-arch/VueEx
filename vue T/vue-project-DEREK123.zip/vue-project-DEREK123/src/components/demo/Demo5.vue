<script setup>

import { ref } from 'vue'; // 內建函式

const count = ref(1);

function addCount() {
    count.value++;
}

// ======================================
import { reactive } from 'vue';


// const style1 = { "color": "red" };
// style1.color;

const style1 = ref({ "color": "green" });
style1.value.color;

const style = reactive({ "color": "green" });

function changeColor() {
    const colors = ["green", "red", "blue", "yellow"];
    const randomIndex = Math.floor(Math.random() * colors.length); // 0~3
    style.color = colors[randomIndex];
}

</script>

<template>

    <button v-on:click="addCount()">{{ count }}</button>

    <button @click="changeColor()" v-bind:style="style">{{ style.color }}</button>

</template>

<style scoped></style>