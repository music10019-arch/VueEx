<script setup>
import { ref } from 'vue';
import Demo17 from './Demo17.vue';


const msg = ref("Hi!!");

const isShow1 = ref(true);
const isShow2 = ref(false);

const inputText = ref();

</script>

<template>
    <p v-pre>{{ msg }}</p>

    <button @click="isShow1 = !isShow1">Click1</button>
    <button @click="isShow2 = !isShow2">Click2</button>
    <p>{{ isShow1 }}</p>
    <p v-memo="[isShow1]">{{ isShow2 }}</p>
    <p>memo外：{{ isShow2 }}</p>

    <Demo17 v-model="inputText"></Demo17>
    {{ inputText }}

</template>

<style scoped></style>