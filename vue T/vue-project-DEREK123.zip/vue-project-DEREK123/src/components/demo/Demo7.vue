<script setup>
import { nextTick, ref } from 'vue';

const count = ref(0);

function click() {
    count.value++;
    const myP = document.querySelector('#p').textContent;
    console.log(myP);
    nextTick(() => {
        const myP = document.querySelector('#p').textContent;
        console.log(myP);
    })
}

//  document.querySelector('#p').addEventListener('click',()=>{

//  })

</script>

<template>

    <p id="p">{{ count }}</p>
    <button @click="click">按鈕</button>


</template>

<style scoped></style>