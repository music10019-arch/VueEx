<script setup>

import axios from 'axios';

fetch('https://fakestoreapi.com/products')
    .then((response) => {
        return response.json();
    }).then((data) => {
        console.log(data);
    }).catch((error) => {
        console.error(error);
    })

axios.get('https://fakestoreapi.com/products')
    .then((response) => {
        console.log(response.data);
    }).catch((error) => {
        console.error(error);
    })

const data = {
    "id": 0,
    "title": "PS5",
    "price": 20000,
    "description": "遊戲主機",
    "category": "string",
    "image": "http://example.com"
}

axios.post('https://fakestoreapi.com/products', data)
    .then((response) => {
        console.log(response.data);
    }).catch((error) => {
        console.error(error);
    })



</script>

<template>



</template>

<style scoped></style>