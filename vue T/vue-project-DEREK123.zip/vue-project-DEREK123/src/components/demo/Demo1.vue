<script setup>

const msg = "本文插值";
const i = 1;

// 宣告式
function getNumber1() {

}

// 表達式
const getNumber = function () {
    return i;
}

// 箭頭函式
const getNumber2 = () => {

}

// document.querySelector("#id").textContent = "本文插值";
// document.getElementById("id").append("本文插值");

</script>

<template>
    <p id="id">{{ msg }}</p> <!-- 本文插值 -->
    <p>{{ i + 1 }}</p> <!-- 2 -->
    <p>{{ getNumber() }}</p> <!-- 1 -->
    <p>{{ i >= 0 ? '有值' : '無值' }}</p>
</template>

<style scoped></style>