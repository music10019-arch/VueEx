<script setup>

import HelloVue from './components/HelloVue.vue';
// import Demo6 from './components/demo/Demo6.vue';
import Demo12345 from './components/demo/Demo10.vue';
import BMIView from './views/BMIView.vue';
import TemperatureView from './views/TemperatureView.vue';

</script>

<template>

  <!-- <h1>Hello APP</h1>
  <HelloVue></HelloVue>-->

  <!-- <Demo12345></Demo12345> -->
  <!-- <TemperatureView></TemperatureView> -->
  <!-- <BMIView></BMIView> -->

  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <RouterLink class="nav-link active" :to="{ name: 'Home' }">首頁</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'About' }">關於我們</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" to="/bmi">1.BMI計算機</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'Temperature' }">2.華氏轉攝氏</RouterLink>
          </li>
          <!-- <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'Demo' }">Demo</RouterLink>
          </li> -->
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'StudentScore' }">3.學生成績單</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'ToDoList' }">4.待辦清單</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'PokemonList' }">5.圖鑑</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'Lifecycle' }">生命週期</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'DemoList' }">DemoList</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'Parent' }">父子組件</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'ShoppingCart' }">購物車</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'PiniaToDoList' }">Pinia待辦</RouterLink>
          </li>
          <li class="nav-item">
            <RouterLink class="nav-link" :to="{ name: 'PiniaShoppingCart' }">Pinia購物車</RouterLink>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- <p>
    <RouterLink :to="{ name: 'Home' }">首頁</RouterLink> |
    <RouterLink :to="{ name: 'About' }">關於我們</RouterLink> |
    <RouterLink to="/bmi">BMI計算機</RouterLink>
  </p> -->
  <hr />
  <div style="width: 80%;margin: auto;">
    <RouterView></RouterView>
  </div>

</template>

<style scoped></style>
