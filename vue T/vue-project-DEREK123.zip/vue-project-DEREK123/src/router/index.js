// 1.匯入vue-router函式
import { createRouter, createWebHistory } from "vue-router";

// 2.匯入組件
import HomeView from "@/views/HomeView.vue";
import AboutView from "@/views/AboutView.vue";
import BMIView from "@/views/BMIView.vue";
import Content1 from "@/views/Content1.vue";
import Content2 from "@/views/Content2.vue";
import NotFound from "@/views/NotFound.vue";
import TemperatureView from "@/views/TemperatureView.vue";

// 3.定義路由
const routes = [
    {
        path: '/:pathMatch(.*)*',
        component: NotFound,
        name: 'NotFound'
    },
    {
        path: '/',
        component: HomeView,
        name: "Home"
    },
    {
        path: '/about',
        component: AboutView,
        name: "About",
        children: [
            {
                path: 'content1/:ids?',
                component: Content1,
                name: 'Content1',
                props: true
            },
            {
                path: 'content2',
                component: Content2,
                name: 'Content2'
            }]
    },
    // {
    //     path: '/about/content1',
    //     component: Content1,
    //     name: "Content1"
    // },
    {
        path: '/bmi',
        component: BMIView,
        name: "Bmi"
    },
    {
        path: '/temperatureView',
        component: TemperatureView,
        name: 'Temperature'
    },
    {
        path: '/demo',
        component: () => import("../components/demo/Demo13.vue"),
        name: 'Demo'
    },
    {
        path: '/studentScore',
        component: () => import("../views/StudentScoreView.vue"),
        name: 'StudentScore'
    },
    {
        path: '/toDoList',
        component: () => import("../views/ToDoListView.vue"),
        name: 'ToDoList'
    },
    {
        path: '/lifecycle',
        component: () => import("../views/Lifecycle.vue"),
        name: 'Lifecycle'
    },
    {
        path: '/demoList',
        component: () => import("../views/DemoList.vue"),
        name: 'DemoList'
    },
    {
        path: '/parent',
        component: () => import("../views/ParentView.vue"),
        name: 'Parent'
    },
    {
        path: '/pokemonList',
        component: () => import("../views/PokemonListView.vue"),
        name: 'PokemonList'
    },
    {
        path: '/shoppingCart',
        component: () => import("../views/ShoppingCartView.vue"),
        name: 'ShoppingCart'
    },
    {
        path: '/piniaToDoList',
        component: () => import("../views/PiniaToDoListView.vue"),
        name: 'PiniaToDoList'
    },
    {
        path: '/piniaShoppingCart',
        component: () => import("../views/PiniaShoppingCartView.vue"),
        name: 'PiniaShoppingCart'
    }
];

// 4.建立router
const router = createRouter({
    history: createWebHistory(),
    routes: routes
});

// 5.匯出
export default router