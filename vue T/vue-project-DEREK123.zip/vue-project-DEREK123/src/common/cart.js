import { Product } from "./product";

export class Cart extends Product {
    constructor(id, name, price, count) {
        super(id, name, price);
        this.count = count;
    }
}