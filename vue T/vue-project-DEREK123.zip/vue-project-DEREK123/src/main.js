import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import 'bootstrap-icons/font/bootstrap-icons.min.css'

import ProjButton from './components/ProjButton.vue';

import { createApp } from 'vue'
import { createPinia } from 'pinia';
import App from './App.vue'

import router from './router';

// 建立Pinia
const pinia = createPinia();
// 創建組件
const app = createApp(App);
// 使用路由
app.use(router);
// 使用Pinia
app.use(pinia);
// 加入全域組件
app.component("ProjButton", ProjButton);
// 掛載到id為app的tag上
app.mount('#app');

// createApp(App).use(router).mount('#app');
