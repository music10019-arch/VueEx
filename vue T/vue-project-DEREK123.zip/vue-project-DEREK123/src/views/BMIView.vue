<script setup>

import { ref } from 'vue';

const height = ref();
const weight = ref();
const bmi = ref(0);
const isHidden = ref(true);

const calBMI = () => {
    const b = (weight.value / Math.pow(height.value * 0.01, 2));
    bmi.value = Number(b.toFixed(2));
    isHidden.value = false;
}

</script>

<template>
    <h1>BMI計算機</h1>
    <hr />
    <div>
        身高(公分cm)：<input type="number" v-model="height" />
        體重(公斤kg)：<input type="number" v-model="weight" />
        <br />
        <!-- <button v-on:click="calBMI()">計算</button> -->
        <ProjButton type="cal" @proj-click="calBMI()"></ProjButton>
        <br />
        <span v-bind:hidden="isHidden">您的BMI：{{ bmi }}</span>
    </div>

</template>


<style scoped>
div {
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: flex-start;
}
</style>