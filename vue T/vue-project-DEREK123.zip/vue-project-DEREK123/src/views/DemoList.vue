<script setup>

import { ref } from 'vue';
import Demo1 from '../components/demo/Demo1.vue';
import Demo2 from '../components/demo/Demo2.vue';
import Demo3 from '../components/demo/Demo3.vue';
import Demo4 from '../components/demo/Demo4.vue';
import Demo5 from '../components/demo/Demo5.vue';
import Demo6 from '../components/demo/Demo6.vue';
import Lifecycle from './Lifecycle.vue';
import Demo14 from '@/components/demo/Demo14.vue';
import Demo15 from '@/components/demo/Demo15.vue';
import Demo16 from '@/components/demo/Demo16.vue';
import Demo17 from '@/components/demo/Demo17.vue';
import Demo18 from '@/components/demo/Demo18.vue';

const componentList = [Demo1, Demo2, Demo3, Demo4, Demo5,
    Demo6, Lifecycle, Demo14, Demo15, Demo16, Demo17, Demo18];

const selectedIndex = ref(11);

</script>

<template>

    <select v-model="selectedIndex">
        <option v-for="(value, index) in componentList" :value="index">
            {{ value.__name }}
            <!-- {{ value }} -->
        </option>
        <!-- <option value="0">Demo1</option>
        <option value="1">Demo2</option>
        <option value="2">Demo3</option>
        <option value="3">Demo4</option> -->
    </select>

    <hr />

    <KeepAlive>
        <component :is="componentList[selectedIndex]"></component>
    </KeepAlive>

</template>


<style scoped></style>