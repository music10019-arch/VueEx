<script setup>
import { useRoute } from 'vue-router';

const route = useRoute();
console.log(route)

const props = defineProps({
    ids: String
})

import { useCounterStore } from '../stores/counter';
import ProjButton from '@/components/ProjButton.vue';
import { onUnmounted } from 'vue';
import { useToDoStore } from '@/stores/todo';

const counterStore = useCounterStore();
counterStore.count;
counterStore.doubleCount;
// counterStore.addCount();

function test() {
    console.log('here');
}
test();

const { addCount } = counterStore;

onUnmounted(() => {
    counterStore.clearCount();
})


const toDoStore = useToDoStore();

const { toDoList } = useToDoStore();

</script>

<template>

    <h1>Content1</h1>
    <p>{{ route.params.ids }}</p>
    <p>{{ props.ids }}</p>

    <hr />
    <div>
        計數：{{ counterStore.count }}
    </div>
    <div>
        計數*2：{{ counterStore.doubleCount }}
    </div>
    <ProjButton type="cal" @proj-click="counterStore.addCount()"></ProjButton>


    <hr>

    <ul>
        <li v-for="(toDo, index) in toDoList" :key="toDo.id">{{ toDo.text }}</li>
    </ul>

</template>

<style scoped></style>