<script setup></script>

<template>

    <h1 style="color: red;">XXX Not Found</h1>

</template>

<style scoped></style>