<script setup>
import Child from '../components/Child.vue';


const titleMsg = "TEST";

function handleChildClick(data) {
    console.log('處理子元件的觸發', data);
}

</script>

<template>

    <h1>父組件</h1>
    <hr />
    <Child @btn-clicked123="handleChildClick($event)" :title="titleMsg" msg="訊息"></Child>


    <Child :title="titleMsg" msg="訊息" :count=1000></Child>


</template>

<style scoped></style>