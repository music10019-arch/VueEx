<script setup></script>

<template>

    <h1>About</h1>

    <RouterLink :to="{ name: 'Content1', params: { ids: 'TEST' } }">Content1</RouterLink> |
    <RouterLink :to="{ name: 'Content2' }">Content2</RouterLink>

    <RouterView></RouterView>

</template>

<style scoped></style>