<script setup>
import { useCounterStore } from '@/stores/counter';
const counterStore = useCounterStore();

</script>

<template>

    <h1>Content2</h1>

    計數*2：{{ counterStore.doubleCount }}

    <button @click="counterStore.addCount()">加1</button>

</template>

<style scoped></style>