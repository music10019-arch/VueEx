<script setup>
import { computed, ref } from 'vue';


const todoList = ref([]);

const inputText = ref();

// 新增
function addToDo() {
    todoList.value.push({
        "id": Date.now(),
        "text": inputText.value,
        "done": false
    });
}

// 刪除
function removeToDo(id) {
    todoList.value = todoList.value.filter(x => x.id != id);
}

// 計算已完成數量
const doneCount = computed(() => {
    return todoList.value.filter(x => x.done).length;
})

// const array = ['a', 'b', 'c'];
// array.push('XXX');
// array.filter();

</script>

<template>

    <h1>待辦清單</h1>
    <hr />

    <div style="display: flex;">
        <input type="text" v-model="inputText" placeholder="輸入新的待辦事項" />
        <ProjButton type="add" @click="addToDo()"></ProjButton>
        <!-- <button @click="addToDo()" class="btn btn-success btn-sm">新增</button> -->
    </div>

    <table>
        <tbody>
            <!-- v-for  -->
            <TransitionGroup>
                <tr v-for="(value, index) in todoList" :key="value.id">
                    <td>
                        <input type="checkbox" v-model="value.done" />
                    </td>
                    <td>
                        <!-- <span :class="value.done ? 'done' : null">{{ value.text }}</span> -->
                        <span :class="{
                            'done': value.done,
                            'test': value.done,
                        }">{{ value.text }}</span>
                    </td>
                    <td>
                        <ProjButton type="delete" @click="removeToDo(value.id)"></ProjButton>
                        <!-- <button class="btn btn-danger btn-sm" @click="removeToDo(value.id)">刪除</button> -->
                    </td>
                </tr>
            </TransitionGroup>
        </tbody>
    </table>
    <p>共 {{ todoList.length }} 項，已完成 {{ doneCount }} 項</p>

</template>

<style scoped>
.done {
    text-decoration: line-through;
    color: grey;
}

.test {
    /* background-color: green; */
}


/* 進入起始 */
.v-enter-from,
/* 離開終點 */
.v-leave-to {
    opacity: 0;
    transform: translateX(30px);
}

/* 進入終點 */
.v-enter-to,
/* 離開起始 */
.v-leave-from {
    /* opacity: 1;
    color: yellow */
}

/* 過度 */
.v-enter-active,
.v-leave-active {
    transition: opacity 1s ease-out, transform 1s ease-out;
}
</style>