<script setup>
import {
    onBeforeMount,
    onMounted,
    onBeforeUpdate,
    onUpdated,
    onBeforeUnmount,
    onUnmounted,
    ref
} from 'vue';

// defineOptions({ name: "TEST" })

const count = ref(1);

const btn = document.querySelector('#t');
console.log(btn);

onBeforeMount(() => {
    console.log('組件掛載前BeforeMount');
})
onMounted(() => {
    console.log('組件掛載後Mounted');
    const btn = document.querySelector('#t');
    console.log(btn);
})

onBeforeUpdate(() => {
    const btn = document.querySelector('#t');
    console.log(btn.textContent);
    console.log('組件更新前BeforeUpdate');
})
onUpdated(() => {
    const btn = document.querySelector('#t');
    console.log(btn.textContent);
    console.log('組件更新後Update');
})

onBeforeUnmount(() => {
    console.log('組件銷毀前BeforeUnmount');
})
onUnmounted(() => {
    console.log('組件銷毀後Unmounted');
})

console.log('Composition API');
</script>

<script>

// 選項式
export default {
    data() {
        console.log('Init Options API');
        return {}
    }
}

</script>

<template>
    <button id="t" @click="count++">{{ count }}</button>
</template>

<style scoped></style>
