<script setup>

import { computed, ref } from 'vue';
import ProductItem from '@/components/ProductItem.vue';
import { Cart } from '@/common/cart';
import { useProductStore } from '@/stores/product';
import ProjButton from '@/components/ProjButton.vue';

const productStore = useProductStore();
// 呼叫後端取得資料
productStore.getProductList();

const cartList = ref([]);
function add(product) {
    const existingCart = cartList.value.find(x => x.id === product.id);
    // console.log(hasValue, !!hasValue);
    // 雙!! 判斷是否有值 是否為真True 是否不為0 | -1還是true
    // map filter find 
    if (!!existingCart) {
        existingCart.count++;
    } else {
        const cart = new Cart(product.id, product.name, product.price, 1);
        cartList.value.push(cart);
    }
}

function getTotal() {
    const sum = cartList.value.reduce((total, item) => {
        return total + item.price * item.count;
    }, 0);
    return sum;
}

const sumPrice = computed(() => {
    const sum = cartList.value.reduce((total, item) => total + item.price * item.count, 0);
    return sum;
})

const name = ref();
const price = ref();

function addProduct() {
    productStore
        .addProduct({ title: name.value, price: price.value })
        .then(() => {
            productStore.getProductList();
        });
}

</script>

<template>
    <div class="p-4">
        <h1>商品清單</h1>
        <div class="item-div">
            <div v-for="(product, index) in productStore.productList" :key="product.id">
                <ProductItem :product="product" @click="add($event)"></ProductItem>
            </div>
        </div>
        <hr />
        <h2>購物車</h2>
        <ul>
            <!-- <li> 商品 - 價格 * 數量 </li> -->
            <li v-for="(cart, index) in cartList" :key="cart.id"> {{ cart.name }} - {{ cart.price }} * {{ cart.count }}
            </li>
        </ul>
    </div>
    總計：${{ sumPrice }}


    <hr>
    <div style="padding: 100px;">
        <h1>新增商品</h1>
        商品名稱：<input type="text" v-model="name" />
        價錢：<input type="number" v-model="price" />
        <ProjButton type="add" @proj-click="addProduct()"></ProjButton>
    </div>

</template>

<style scoped>
.item-div {
    display: flex;
    flex-wrap: wrap;
}
</style>