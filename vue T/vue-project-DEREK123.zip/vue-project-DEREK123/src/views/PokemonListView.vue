<script setup>
// 資料來源
import pokemonData from '../data/pokemon.json';
// 要使用響應式
import { computed, ref } from 'vue';
// 自製子組件
import PokemonCard from '@/components/PokemonCard.vue';

const pokemons = ref(pokemonData);

// const pokemonList = computed(() => {

//     const newList = pokemons.value.map(x => {
//         let newData = {
//             number: x.number,
//             name: x.name,
//             typeDisplay: getTypeDisplay(x.types),
//             image: x.image
//         }
//         return newData;
//     })

//     return newList;
// })


const pokemonList = computed(() => {
    return p1.value.map(x => {
        return {
            number: x.number,
            name: x.name,
            typeDisplay: getTypeDisplay(x.types),
            image: x.image
        }
    })
})

function getTypeDisplay(typeArray) {
    console.log('here');
    return typeArray.join("、");
}


const searchText = ref();



function search() {
    if (searchText.value) {
        pokemons.value = pokemonData.filter(x => x.name.includes(searchText.value));
    } else {
        pokemons.value = pokemonData;
    }
}

const p1 = computed(() => {
    if (searchText.value) {
        return pokemonData.filter(x => x.name.includes(searchText.value));
    } else {
        return pokemonData;
    }
})



</script>

<template>

    <!-- <input v-model="searchText" @input="search()" /> -->
    <input v-model="searchText" />
    <div class="myDiv">
        <div v-for="(value, index) in pokemonList" :key="value.number">
            <PokemonCard :name="value.name">
                <img :src="value.image">
                <template #types>{{ value.typeDisplay }}</template>
                <template #number>{{ value.number }}</template>
            </PokemonCard>
        </div>
    </div>

</template>

<style scoped>
.myDiv {
    display: flex;
    flex-wrap: wrap;
}
</style>