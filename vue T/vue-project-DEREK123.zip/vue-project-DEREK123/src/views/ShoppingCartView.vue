<script setup>

import { computed, ref } from 'vue';
import ProductItem from '@/components/ProductItem.vue';
import { Product } from '../common/product';
import { Cart } from '@/common/cart';

const products = ref([
    new Product(1, '麥克雙牛堡', 100),
    new Product(2, '麥克雞塊餐', 120),
    new Product(3, '麥脆雞餐', 150),
]);

const cartList = ref([]);
function add(product) {
    const existingCart = cartList.value.find(x => x.id === product.id);
    // console.log(hasValue, !!hasValue);
    // 雙!! 判斷是否有值 是否為真True 是否不為0 | -1還是true
    // map filter find 
    if (!!existingCart) {
        existingCart.count++;
    } else {
        const cart = new Cart(product.id, product.name, product.price, 1);
        cartList.value.push(cart);
    }
}

function getTotal() {
    const sum = cartList.value.reduce((total, item) => {
        return total + item.price * item.count;
    }, 0);
    return sum;
}

const sumPrice = computed(() => {
    const sum = cartList.value.reduce((total, item) => total + item.price * item.count, 0);
    return sum;
})

</script>

<template>
    <div class="p-4">
        <h1>商品清單</h1>
        <div class="item-div">
            <div v-for="(product, index) in products" :key="product.id">
                <ProductItem :product="product" @click="add($event)"></ProductItem>
            </div>
        </div>
        <hr />
        <h2>購物車</h2>
        <ul>
            <!-- <li> 商品 - 價格 * 數量 </li> -->
            <li v-for="(cart, index) in cartList" :key="cart.id"> {{ cart.name }} - {{ cart.price }} * {{ cart.count }}
            </li>
        </ul>
    </div>
    總計：${{ sumPrice }}
</template>

<style scoped>
.item-div {
    display: flex;
    flex-wrap: wrap;
}
</style>