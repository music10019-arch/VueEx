<script setup></script>

<template>

    <h1>Home</h1>


    <button class="btn btn-success">Success!!!</button>

</template>

<style scoped></style>