<script setup>

const headList = ['名字', '國文', '英文', '數學'];
import { computed, ref } from 'vue';
import studentData from '../data/student.json';

const studentList = ref(studentData);

const searchText = ref();

function searchByName() {
    if (searchText.value) {
        // 篩選
        // array
        studentList.value = studentData.filter(e => e.name.includes(searchText.value))
    } else {
        // 原始資料
        studentList.value = studentData;
    }
}

document.querySelector("#d").addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();
}, true)

const students = computed(() => {
    if (searchText.value) {
        return studentData
            .filter(e => e.name.toLocaleLowerCase()
                .includes(searchText.value.toLocaleLowerCase()));
    } else {
        return studentData;
    }
})

</script>

<template>
    <h1>學生成績單</h1>
    <hr />
    <h3>
        {{ searchText }}
        <!-- 名字搜尋：<input type="text" v-model="searchText" @keyup="searchByName()" /> -->
        名字搜尋：<input type="text" v-model="searchText" />
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th colspan="4">學生成績單</th>
            </tr>
            <tr>
                <th v-for="(head, index) in headList" :key="index">{{ head }}</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="student in students" :key="student.id">
                <td>{{ student.name }}</td>
                <td>{{ student.chinese }}</td>
                <td>{{ student.english }}</td>
                <td>{{ student.math }}</td>
            </tr>
            <!-- <tr>
                <td>Derek</td>
                <td>60</td>
                <td>80</td>
                <td>90</td>
            </tr>
            <tr>
                <td>Derek2</td>
                <td>60</td>
                <td>80</td>
                <td>90</td>
            </tr> -->
        </tbody>
    </table>

</template>


<style scoped></style>