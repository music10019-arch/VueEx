import { defineStore } from "pinia";
import { computed, ref } from "vue";

export const useCounterStore = defineStore('counter', () => {

    // 響應式資料
    const count = ref(0);

    // Computed
    const doubleCount = computed(() => count.value * 2);

    const countO = computed(() => count.value);

    // [函式] Count+1
    function addCount() {
        count.value++;
    }

    // [函示] 清除Count
    function clearCount() {
        count.value = 0;
    }

    const privateCount = ref(0);
    // 給外部使用 要記得return
    return { count, doubleCount, countO, addCount, clearCount }
})