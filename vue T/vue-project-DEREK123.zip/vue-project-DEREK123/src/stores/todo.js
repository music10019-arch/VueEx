import { defineStore } from "pinia";
import { computed, ref } from "vue";

export const useToDoStore = defineStore('toDo', () => {

    const toDoList = ref([]);

    function addToDo(inputText) {
        toDoList.value.push({
            "id": Date.now(),
            "text": inputText,
            "done": false
        })
    }
    // 刪除
    function removeToDo(id) {
        toDoList.value = toDoList.value.filter(x => x.id != id);
    }

    // 全部數量
    const count = computed(() => {
        return toDoList.value.length;
    })

    // 已完成數量
    const doneCount = computed(() => {
        return toDoList.value.filter(x => x.done).length;
    })


    return { toDoList, addToDo, removeToDo, count, doneCount };
})