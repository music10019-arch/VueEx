import { Product } from "@/common/product";
import { defineStore } from "pinia";
import { ref } from "vue";
import axios from "axios";

export const useProductStore = defineStore('product', () => {

    const productList = ref([
        // new Product(1, '麥克雙牛堡', 100),
        // new Product(2, '麥克雞塊餐', 120),
        // new Product(3, '麥脆雞餐', 1500),
    ]);


    function getProductList() {
        axios.get("https://fakestoreapi.com/products")
            .then((response) => {
                productList.value = response.data.map(x => new Product(x.id, x.title, x.price));
            }).catch((error) => {
                console.error(error);
            })
    }

    async function addProduct(data) {
        axios.post("https://fakestoreapi.com/products", data)
            .then((response) => {
                console.log(response.data);
                const { data } = response;
                productList.value.push(new Product(data.id, data.title, data.price));
            }).catch((error) => {
                console.error(error)
            })
    }

    return { productList, getProductList, addProduct };
})